# flowable-springboot
the demo for flowable-springboot
# 博文：采用springboot+flowable快速实现工作流
## 链接 [https://blog.csdn.net/puhaiyang/article/details/79845248](https://blog.csdn.net/puhaiyang/article/details/79845248)
